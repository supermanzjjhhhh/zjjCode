@javax.xml.bind.annotation.XmlSchema(namespace = "http://itf.workorder.bs.nc/WorkOrderServiceItf")
package com.example.demo.wbservice;
